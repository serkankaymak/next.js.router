// src/app/about/page.tsx
export default function Email() {
    return (
        <main>
            <h1>email sender</h1>
        </main>
    );
}
