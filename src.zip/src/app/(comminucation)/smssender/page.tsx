// src/app/about/page.tsx
export default function Sms() {
    return (
        <main>
            <h1>sms sender </h1>
        </main>
    );
}
