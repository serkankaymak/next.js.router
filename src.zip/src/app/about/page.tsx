// src/app/about/page.tsx
export default function About() {
    return (
      <main>
        <h1>Hakkında</h1>
        <p>Bu sayfa hakkında bilgiler içerir.</p>
      </main>
    );
  }
  