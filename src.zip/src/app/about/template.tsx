export default function Template({ children }: { children: React.ReactNode }) {
    return <div>

        <div style={{ textAlign: "center", backgroundColor: "wheat" }}>
            Template
            {children}
        </div>
    </div>
}