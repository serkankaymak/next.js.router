import Image from 'next/image'
// src/app/page.tsx
export default function ComponentB() {
    return (
        <main>
            <h1>ComponentB</h1>
            <Image

                src="https://s3.amazonaws.com/my-bucket/profile.png"
                alt="Picture of the author"
                width={500}
                height={500}

            ></Image>
        </main>
    );
}
