'use client'
import { useState } from 'react'
import dynamic from 'next/dynamic'

import { useRouter } from 'next/navigation'


// Client Components:
const ComponentA = dynamic(() => import('./componenta'))
const ComponentB = dynamic(() => import('./componentb'))
const ComponentC = dynamic(() => import('./componentc'), { ssr: false })

export default function Page() {
    const router = useRouter()
    const [showMore, setShowMore] = useState(false)
    return (
        <div>
            <div>
                <button type="button" onClick={() => router.push('/dashboard')}>
                    Go To Dashboard
                </button>
            </div>
            <hr />
            <div>
                <div>
                    {/* Load immediately, but in a separate client bundle */}
                    <ComponentA />


                    {/* Load on demand, only when/if the condition is met */}
                    <button onClick={() => setShowMore(!showMore)}>Show ComponentB</button>
                    {showMore && <ComponentB />}


                    {/* Load only on the client side */}
                    {/* Tarayıcı da işlenmesi gereken verielr olduğunda mesela. */}
                    <ComponentC />
                </div>
            </div>
        </div>


    )
}