'use client'

import React, { useState } from "react";

interface ContactChildProps {
    title: string;
    subtitle?: string;
}

interface ContactChildState {
    isActive: boolean;
}

const ContactChildComponent: React.FC<ContactChildProps> = ({ title, subtitle }) => {
    const [state, setState] = useState<ContactChildState>({
        isActive: false,
    });

    const toggleActive = () => {
        setState((prevState) => ({
            ...prevState,
            isActive: !prevState.isActive,
        }));
    };

    return (
        <main style={{ backgroundColor: 'wheat' }}>
            <h4>{title}</h4>
            {subtitle && <p>{subtitle}</p>}
            <button onClick={toggleActive}>
                {state.isActive ? "Deactivate" : "Activate"}
            </button>
        </main>
    );
};

export default ContactChildComponent;
