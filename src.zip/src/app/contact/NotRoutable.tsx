

// src/app/about/page.tsx
export default function NotRoutable() {
    return (
        <main>
            NotRoutable
        </main>
    );
}
