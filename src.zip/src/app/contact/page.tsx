import ContactChildComponent from "./ContactChildComponent";

// src/app/about/page.tsx
export default function Contact() {
    return (
        <main>
            <h1>Contact</h1>
            <ContactChildComponent title={"ContactChildComponent"}></ContactChildComponent>
        </main>
    );
}
