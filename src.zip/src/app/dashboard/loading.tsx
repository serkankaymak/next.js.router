import { randomInt } from "crypto";
import { redirect } from 'next/navigation'


// src/app/about/page.tsx
export default function Loading() {

    const isAuthendicateuser: boolean = randomInt(7) % 2 == 0;
    if (!isAuthendicateuser) redirect('/');

    return (
        <main>
            LOADİNG....
        </main>
    );

}
