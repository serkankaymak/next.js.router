import { randomInt } from "crypto";
import Link from "next/link"
import { redirect } from 'next/navigation'


// src/app/about/page.tsx
export default function Dashboard() {

    const isAuthendicateuser: boolean = randomInt(7) % 2 == 0;
    if (!isAuthendicateuser) redirect('/');

    return (
        <main>
            <ul>
                <li>
                    <Link href="dashboard/settings"> Go  Settings</Link>
                </li>
            </ul>
        </main>
    );

}
