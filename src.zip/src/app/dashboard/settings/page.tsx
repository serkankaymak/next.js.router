// src/app/about/page.tsx
export default function Settings() {
    return (
        <main>
            <h1> Dashboard /  Settings</h1>
        </main>
    );
}
