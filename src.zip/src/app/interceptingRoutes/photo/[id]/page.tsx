

type tParams = Promise<{ id: string }>;

export default async function PhotoPage(props: { params: tParams }) {
    console.log(await props.params);
    const _params = await props.params;
    console.log(_params);
    const photoId = _params.id;


    return (
        <main>
            <p>photo Modal opened : {photoId}</p>
        </main>
    );
}


