// src/app/layout.tsx
import '../styles/globals.css';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { ReactNode } from 'react';

export const metadata = {
  title: 'My Next.js App',
  description: 'Next.js uygulaması',
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="tr">
      <body>
        <Header />

        {children}
        <div
          style={{ position: 'fixed', bottom: 0, left: 0, right: 0 }}
        >
          <Footer />
        </div>

      </body>
    </html>
  );
}
