import Image from 'next/image'
// src/app/page.tsx
export default function Home() {
  return (
    <main>
      <h1>Ana Sayfa2</h1>
      <Image

        src="https://s3.amazonaws.com/my-bucket/profile.png"
        alt="Picture of the author"
        width={500}
        height={500}

      ></Image>
    </main>
  );
}
