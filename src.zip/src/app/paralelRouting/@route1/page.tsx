// src/app/page.tsx
export default function Route1() {
    return (
        <main>
            <h4>Route1</h4>
        </main>
    );
}
