// src/app/page.tsx
export default function Route2() {
    return (
        <main>
            <h4>Route2</h4>
        </main>
    );
}
