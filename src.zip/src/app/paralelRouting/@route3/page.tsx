// src/app/page.tsx
export default function Route3() {
    return (
        <main>
            <h4>Route3</h4>
        </main>
    );
}
