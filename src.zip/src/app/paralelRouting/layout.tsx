import { randomInt } from "crypto"

export default function Layout({
    children,
    route1,
    route2,
    route3
}: {
    children: React.ReactNode
    route1: React.ReactNode
    route2: React.ReactNode
    route3: React.ReactNode
}) {

    const checkUserIsAdmin = () => randomInt(105) % 2 == 0;

    return (
        <>
            <div>
                {children}
                {route1}
                {route2}
                {checkUserIsAdmin() == true ? route3 : ""}
            </div>
        </>
    )
}