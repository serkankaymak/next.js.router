// src/app/page.tsx
export default function ParalelRouting() {
    return (
        <main>
            <h1>ParalelRouting</h1>
        </main>
    );
}
