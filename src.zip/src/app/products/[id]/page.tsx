import Link from "next/link";
import { notFound } from "next/navigation";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
}

async function getProduct(id: string): Promise<Product | null> {

  try {
    const res = await fetch(`http://localhost:5191/api/products/${id}`, {
      cache: "no-store",
    });
    if (!res.ok) {
      return null;
    }
    return res.json();
  } catch (e) {
    console.log(e);
    return null;
  }

}


type tParams = Promise<{ id: string }>;

export default async function ProductDetailPage(props: { params: tParams }) {
  console.log(await props.params);
  const _params = await props.params;
  console.log(_params);
  const productID = _params.id;
  console.log(productID);
  const product = await getProduct(productID);

  if (!product) {
    console.log("products null döndü");
    return notFound();
  }


  return (
    <main>
      <h1>{product.name}</h1>
      <p>açıklama: {product.description}</p>
      <p>fiyat: {product.price} TL</p>

      <li key={product.id}>
        <Link href={`/products/review/${product.id}`}>{product.name}</Link>
      </li>



    </main>
  );
}



/**
 * 
export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const _id = (await params).id;
  const product = await getProduct(_id);

  if (!product) {
    return notFound();
  }

  return (
    <main>
      <h1>{product.name}</h1>
      <p>Açıklama: {product.description}</p>
      <p>Fiyat: {product.price} TL</p>
    </main>
  );
}

 */



