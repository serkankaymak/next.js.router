// src/app/products/page.tsx
import Link from 'next/link';

interface Product {
  id: number;
  name: string;
}

async function getProducts(): Promise<Product[]> {
  const res = await fetch('http://localhost:5191/api/products', {
    cache: 'no-store',
  });

  if (!res.ok) {
    throw new Error('Failed to fetch products');
  }

  return res.json();
}

export default async function ProductsPage() {
  const products = await getProducts();

  return (
    <main>
      <h1>Ürünler</h1>
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <Link href={`/products/${product.id}`}>{product.name}</Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
