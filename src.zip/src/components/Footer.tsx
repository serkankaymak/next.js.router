// src/components/Footer.tsx
export default function Footer() {
  return (
    <footer style={{ display: "flex", justifyContent: "center" }}>
      <p> footer</p>
    </footer>
  );
}
