// src/components/Header.tsx
import Link from 'next/link';

export default function Header() {
  return (
    <header>
      <nav>
        <ul style={{ display: "flex", justifyContent: "center" }}>
          <li>
            <Link href="/">Ana Sayfa</Link>
          </li>
          <li>
            <Link href="/about">Hakkında</Link>
          </li>
          <li>
            <Link href="/products">Ürünler</Link>
          </li>
          <li>
            <Link href="/clientcomponent">clientcomponent</Link>
          </li>

          <li>
            <Link href="/dashboard">Dashboard</Link>
          </li>

          <li>
            <Link href="/contact">Contact</Link>
          </li>

          <li>
            <Link href="/emailsender">Email Sender</Link>
          </li>

          <li>
            <Link href="/smssender">Sms Sender</Link>
          </li>
          <li>
            <Link href="/paralelRouting">ParalelRouting</Link>
          </li>



        </ul>
      </nav>
    </header>
  );
}
